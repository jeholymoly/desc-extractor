
import React, { useState, useCallback } from 'react';
import { Header } from './components/layout/Header';
import { InputTabs } from './components/input/InputTabs';
import { ExclusionSettings } from './components/input/ExclusionSettings';
import { ResultsDisplay } from './components/results/ResultsDisplay';
import { LoadingSpinner } from './components/shared/LoadingSpinner';
import { Alert } from './components/shared/Alert';
import { analyzeShoeDescription } from './services/geminiService';
import type { AnalysisResult, RawAnalysisResult } from './types';
import { parseExcelFile } from './utils/excelParser';

const App: React.FC = () => {
  const [analysisResults, setAnalysisResults] = useState<AnalysisResult[]>([]);
  const [exclusionTerms, setExclusionTerms] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [progressMessage, setProgressMessage] = useState<string | null>(null);

  const handleAnalyze = useCallback(async (descriptions: string[]) => {
    if (descriptions.length === 0) {
      setError("Please provide at least one description to analyze.");
      return;
    }
    if (!process.env.API_KEY) {
      setError("API Key is not configured. Please ensure the API_KEY environment variable is set.");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysisResults([]);
    setProgressMessage(descriptions.length > 1 ? `Starting analysis for ${descriptions.length} descriptions...` : null);

    const newResults: AnalysisResult[] = [];
    try {
      for (let i = 0; i < descriptions.length; i++) {
        const description = descriptions[i];
        if (descriptions.length > 1) {
          setProgressMessage(`Analyzing description ${i + 1} of ${descriptions.length}...`);
        }
        const resultData: RawAnalysisResult = await analyzeShoeDescription(description, exclusionTerms);
        newResults.push({
          id: crypto.randomUUID(),
          originalDescription: description, // Use the original input description
          ...resultData,
        });
      }
      setAnalysisResults(newResults);
    } catch (err) {
      console.error("Analysis error:", err);
      setError(err instanceof Error ? err.message : "An unknown error occurred during analysis.");
    } finally {
      setIsLoading(false);
      setProgressMessage(null);
    }
  }, [exclusionTerms]);

  const handleTextSubmit = (text: string) => {
    if (!text.trim()) {
        setError("Text input cannot be empty.");
        return;
    }
    handleAnalyze([text]);
  };

  const handleFileSubmit = async (file: File) => {
    setIsLoading(true);
    setError(null);
    setProgressMessage("Parsing Excel file...");
    try {
      const descriptions = await parseExcelFile(file);
      if (descriptions.length === 0) {
        setError("No descriptions found in the Excel file or the file is empty/incorrectly formatted. Please ensure descriptions are in the first column.");
        setIsLoading(false);
        setProgressMessage(null);
        return;
      }
      setProgressMessage(null);
      handleAnalyze(descriptions);
    } catch (err) {
      console.error("File processing error:", err);
      setError(err instanceof Error ? err.message : "Failed to process Excel file.");
      setIsLoading(false);
      setProgressMessage(null);
    }
  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-gray-100 flex flex-col items-center p-4 sm:p-6">
      <Header />
      <main className="container mx-auto mt-6 w-full max-w-5xl bg-slate-800 shadow-2xl rounded-lg p-6 sm:p-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1 space-y-6">
            <ExclusionSettings
              terms={exclusionTerms.join(', ')}
              onChange={(newTerms) => setExclusionTerms(newTerms.split(',').map(t => t.trim()).filter(t => t))}
            />
          </div>
          <div className="md:col-span-2">
            <InputTabs 
              onTextSubmit={handleTextSubmit} 
              onFileSubmit={handleFileSubmit}
              isLoading={isLoading}
            />
          </div>
        </div>

        {isLoading && (
          <div className="mt-8 text-center">
            <LoadingSpinner />
            {progressMessage && <p className="mt-2 text-pink-400">{progressMessage}</p>}
            {!progressMessage && <p className="mt-2 text-pink-400">Analyzing... this may take a moment.</p>}
          </div>
        )}

        {error && (
          <div className="mt-8">
            <Alert type="error" message={error} onClose={() => setError(null)} />
          </div>
        )}

        {!isLoading && analysisResults.length > 0 && (
          <div className="mt-8">
            <h2 className="text-2xl font-semibold mb-6 text-pink-400">Analysis Results</h2>
            <ResultsDisplay results={analysisResults} />
          </div>
        )}
      </main>
      <footer className="text-center py-8 text-sm text-gray-500">
        Powered by AI &nbsp;&bull;&nbsp; Shoe Intellect &copy; {new Date().getFullYear()}
      </footer>
    </div>
  );
};

export default App;
