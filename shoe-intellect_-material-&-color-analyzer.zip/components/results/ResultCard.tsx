import React from 'react';
import type { AnalysisResult, MaterialAnalysis, ColorAnalysis, ExcludedPart } from '../../types';

interface ResultCardProps {
  result: AnalysisResult;
}

const DetailItem: React.FC<{ label: string; value: string | undefined | null; className?: string }> = ({ label, value, className }) => (
  value ? <p className={`text-sm ${className || 'text-gray-300'}`}><strong className="text-gray-100">{label}:</strong> {value}</p> : null
);

const MaterialPill: React.FC<{type: MaterialAnalysis['type']}> = ({type}) => {
  let bgColor = 'bg-gray-600';
  let textColor = 'text-gray-100';
  if (type === 'SOLID') {
    bgColor = 'bg-green-700'; // More vibrant green for SOLID
    textColor = 'text-green-100';
  } else if (type === 'REGRIND') {
    bgColor = 'bg-yellow-600'; // Distinct yellow for REGRIND
    textColor = 'text-yellow-100';
  } else { // UNKNOWN
    bgColor = 'bg-slate-500';
    textColor = 'text-slate-100';
  }
  return <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${bgColor} ${textColor}`}>{type}</span>
}

export const ResultCard: React.FC<ResultCardProps> = ({ result }) => {
  return (
    <div className="bg-slate-700 rounded-lg shadow-lg p-4 sm:p-6 mb-6 transition-all duration-300 hover:shadow-pink-500/30">
      <h3 className="text-lg font-semibold text-pink-400 mb-1">Original Description:</h3>
      <p className="text-gray-300 mb-4 text-sm italic bg-slate-600 p-3 rounded-md">{result.originalDescription}</p>
      
      {result.summary && (
         <>
            <h4 className="text-md font-semibold text-indigo-400 mt-3 mb-1">AI Summary:</h4>
            <p className="text-gray-300 text-sm mb-4">{result.summary}</p>
         </>
      )}

      {result.materials.length > 0 && (
        <div className="mb-4">
          <h4 className="text-md font-semibold text-indigo-400 mb-2">Materials Detected:</h4>
          <ul className="space-y-3">
            {result.materials.map((material, index) => (
              <li key={index} className="p-3 bg-slate-600 rounded-md">
                <div className="flex items-center mb-1">
                    <MaterialPill type={material.type} />
                    <p className="ml-2 text-gray-100 font-medium">{material.mention}</p>
                </div>
                <DetailItem label="Reasoning" value={material.reasoning} className="text-xs text-gray-400" />
              </li>
            ))}
          </ul>
        </div>
      )}

      {result.colors.length > 0 && (
        <div className="mb-4">
          <h4 className="text-md font-semibold text-indigo-400 mb-2">Colors Identified:</h4>
          <ul className="space-y-3">
            {result.colors.map((color, index) => (
              <li key={index} className="p-3 bg-slate-600 rounded-md">
                <p className="text-gray-100 font-medium">{color.name} <span className="text-xs px-1.5 py-0.5 bg-purple-600 text-purple-100 rounded-full">{color.category}</span></p>
                <DetailItem label="Mention" value={color.mention} className="text-xs text-gray-400" />
              </li>
            ))}
          </ul>
        </div>
      )}

      {result.excludedParts.length > 0 && (
        <div className="mt-4 p-3 bg-red-900/30 border border-red-700 rounded-md">
          <h4 className="text-md font-semibold text-red-300 mb-2">Excluded Parts/Labels:</h4>
          <ul className="space-y-2">
            {result.excludedParts.map((part, index) => (
              <li key={index} className="p-2 bg-slate-600 rounded">
                <p className="text-gray-100 font-medium">Term: "{part.term}"</p>
                <DetailItem label="Mention in text" value={part.mention} className="text-xs text-gray-400" />
                <DetailItem label="Reason for exclusion" value={part.reasoning} className="text-xs text-gray-400"/>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {result.materials.length === 0 && result.colors.length === 0 && result.excludedParts.length === 0 && !result.summary && (
        <p className="text-gray-400 italic">No specific details could be extracted based on the current analysis parameters.</p>
      )}
    </div>
  );
};
