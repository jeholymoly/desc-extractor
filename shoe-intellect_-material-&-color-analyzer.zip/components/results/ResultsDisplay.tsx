import React from 'react';
import type { AnalysisResult } from '../../types';
import { ResultCard } from './ResultCard';

interface ResultsDisplayProps {
  results: AnalysisResult[];
}

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ results }) => {
  if (results.length === 0) {
    return (
      <div className="text-center py-10">
        {/* This message will be shown if App.tsx calls it with empty results BEFORE any analysis. 
            After analysis, if nothing is found, individual cards might show "No specific details..."
            App.tsx also has its own logic for initial state or post-analysis empty results.
            This component's message is a fallback.
        */}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {results.map((result) => (
        <ResultCard key={result.id} result={result} />
      ))}
    </div>
  );
};
