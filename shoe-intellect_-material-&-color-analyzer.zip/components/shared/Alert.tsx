import React from 'react';

interface AlertProps {
  type: 'error' | 'success' | 'info';
  message: string;
  onClose?: () => void;
}

export const Alert: React.FC<AlertProps> = ({ type, message, onClose }) => {
  const baseClasses = "p-4 rounded-md flex items-start text-sm shadow-lg";
  let typeClasses = "";
  let iconSvgPath: string = "";
  let iconClasses = "h-5 w-5 mr-3";

  switch (type) {
    case 'error':
      typeClasses = "bg-red-800 text-red-100 border border-red-700";
      iconClasses += " text-red-300";
      iconSvgPath = "M10 18a8 8 0 100-16 8 8 0 000 16zm0-2a6 6 0 100-12 6 6 0 000 12zm-1-5a1 1 0 102 0v-2a1 1 0 10-2 0v2zm0 3a1 1 0 102 0 1 1 0 00-2 0z";
      break;
    case 'success':
      typeClasses = "bg-green-800 text-green-100 border border-green-700";
      iconClasses += " text-green-300";
      iconSvgPath = "M10 18a8 8 0 100-16 8 8 0 000 16zm0-2a6 6 0 100-12 6 6 0 000 12zm-1.707-4.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4a1 1 0 00-1.414-1.414L9 10.586l-1.707-1.707z";
      break;
    case 'info':
      typeClasses = "bg-blue-800 text-blue-100 border border-blue-700";
      iconClasses += " text-blue-300";
      iconSvgPath = "M10 18a8 8 0 100-16 8 8 0 000 16zm0-2a6 6 0 100-12 6 6 0 000 12zm1-6a1 1 0 10-2 0v4a1 1 0 102 0V10zM9 7a1 1 0 112 0 1 1 0 01-2 0z";
      break;
  }

  return (
    <div className={`${baseClasses} ${typeClasses}`} role="alert">
      <svg className={iconClasses} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <path clipRule="evenodd" fillRule="evenodd" d={iconSvgPath} />
      </svg>
      <div className="flex-grow">{message}</div>
      {onClose && (
        <button 
          onClick={onClose} 
          className="ml-4 p-1 -m-1 rounded-md hover:bg-opacity-20 hover:bg-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-opacity-50"
          aria-label="Close alert"
        >
          <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <path clipRule="evenodd" fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" />
          </svg>
        </button>
      )}
    </div>
  );
};
