import React from 'react';

interface ExclusionSettingsProps {
  terms: string;
  onChange: (newTerms: string) => void;
}

export const ExclusionSettings: React.FC<ExclusionSettingsProps> = ({ terms, onChange }) => {
  return (
    <div className="p-4 bg-slate-700 rounded-lg shadow">
      <label htmlFor="exclusion-terms" className="block text-sm font-medium text-gray-200 mb-1">
        Exclusion Terms (comma-separated)
      </label>
      <p className="text-xs text-gray-400 mb-2">
        Words or phrases to be identified as internal labels and excluded from primary analysis.
      </p>
      <input
        type="text"
        id="exclusion-terms"
        value={terms}
        onChange={(e) => onChange(e.target.value)}
        placeholder="e.g., internal_code, do_not_use"
        className="w-full p-2 bg-slate-600 border border-slate-500 rounded-md focus:ring-pink-500 focus:border-pink-500 text-gray-100 placeholder-gray-400"
        aria-describedby="exclusion-terms-description"
      />
      <p id="exclusion-terms-description" className="sr-only">
        Enter terms separated by commas that should be excluded from the analysis. For example, internal_code, do_not_use.
      </p>
    </div>
  );
};
