import React, { useState, useRef } from 'react';

interface InputTabsProps {
  onTextSubmit: (text: string) => void;
  onFileSubmit: (file: File) => void;
  isLoading: boolean;
}

export const InputTabs: React.FC<InputTabsProps> = ({ onTextSubmit, onFileSubmit, isLoading }) => {
  const [activeTab, setActiveTab] = useState<'text' | 'file'>('text');
  const [textInput, setTextInput] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleTextSubmit = () => {
    if (textInput.trim()) {
      onTextSubmit(textInput);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onFileSubmit(file);
      // Reset file input to allow re-upload of the same file name
      if (fileInputRef.current) {
        fileInputRef.current.value = ""; 
      }
    }
  };

  const commonButtonClasses = "w-full font-semibold py-2 px-4 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800";
  const activeButtonClasses = "bg-pink-600 hover:bg-pink-700 text-white";
  const disabledButtonClasses = "bg-gray-500 text-gray-300 cursor-not-allowed";

  return (
    <div className="bg-slate-700 p-4 sm:p-6 rounded-lg shadow">
      <div className="mb-4 border-b border-slate-600">
        <nav className="-mb-px flex space-x-4" aria-label="Tabs">
          {['text', 'file'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as 'text' | 'file')}
              className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm
                ${activeTab === tab
                  ? 'border-pink-500 text-pink-400'
                  : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
                }`}
              aria-current={activeTab === tab ? 'page' : undefined}
            >
              {tab === 'text' ? 'Text Input' : 'Upload Excel File'}
            </button>
          ))}
        </nav>
      </div>

      {activeTab === 'text' && (
        <div className="space-y-4">
          <label htmlFor="text-description" className="sr-only">Shoe Description</label>
          <textarea
            id="text-description"
            rows={6}
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            placeholder="Paste shoe description here..."
            className="w-full p-3 bg-slate-600 border border-slate-500 rounded-md focus:ring-pink-500 focus:border-pink-500 text-gray-100 placeholder-gray-400"
            disabled={isLoading}
            aria-label="Shoe description text input"
          />
          <button
            onClick={handleTextSubmit}
            disabled={isLoading || !textInput.trim()}
            className={`${commonButtonClasses} ${isLoading || !textInput.trim() ? disabledButtonClasses : activeButtonClasses}`}
          >
            {isLoading ? 'Analyzing...' : 'Analyze Text'}
          </button>
        </div>
      )}

      {activeTab === 'file' && (
        <div className="space-y-4">
          <label htmlFor="file-upload" className="block text-sm font-medium text-gray-300 mb-1">
            Upload .xlsx file
          </label>
          <input
            type="file"
            id="file-upload"
            ref={fileInputRef}
            accept=".xlsx"
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-400
                       file:mr-4 file:py-2 file:px-4
                       file:rounded-md file:border-0
                       file:text-sm file:font-semibold
                       file:bg-pink-600 file:text-white
                       hover:file:bg-pink-700
                       disabled:opacity-50"
            disabled={isLoading}
            aria-label="Excel file upload for shoe descriptions"
          />
           <p className="text-xs text-gray-400">
            Ensure descriptions are in the first column of the first sheet.
          </p>
        </div>
      )}
    </div>
  );
};
