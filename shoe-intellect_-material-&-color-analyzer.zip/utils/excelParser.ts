import * as XLSX from 'xlsx';

export const parseExcelFile = (file: File): Promise<string[]> => {
  return new Promise((resolve, reject) => {
    if (!file) {
      return reject(new Error("No file provided for parsing."));
    }
    if (file.size === 0) {
      return reject(new Error("The provided file is empty."));
    }
    // Basic check for .xlsx extension, though MIME type check in InputTabs is better
    if (!file.name.toLowerCase().endsWith('.xlsx')) {
        return reject(new Error("Invalid file type. Please upload a .xlsx file."));
    }

    const reader = new FileReader();

    reader.onload = (event: ProgressEvent<FileReader>) => {
      if (!event.target?.result) {
        return reject(new Error("Failed to read file content."));
      }
      try {
        const workbook = XLSX.read(event.target.result, { type: 'binary' });
        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
            return reject(new Error("No sheets found in the Excel file. The file might be empty or corrupted."));
        }
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        if (!worksheet) {
             return reject(new Error(`Sheet "${firstSheetName}" could not be read or is empty.`));
        }
        
        // Convert sheet to JSON array of arrays (rows).
        // `header: 1` makes each row an array of cells.
        // `blankrows: false` attempts to skip totally blank rows.
        const jsonData: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1, blankrows: false });
        
        const descriptions: string[] = jsonData
          .map(row => row && row[0]) // Get the first cell of each row, ensure row exists
          .filter(cellValue => cellValue !== null && typeof cellValue !== 'undefined' && String(cellValue).trim() !== '') // Filter out empty or undefined values
          .map(cellValue => String(cellValue).trim()); // Convert to string and trim

        if (descriptions.length === 0) {
            // Resolve with empty array, App.tsx will show "No descriptions found..."
            resolve([]);
            return;
        }
        resolve(descriptions);
      } catch (e) {
        console.error("Error parsing Excel file:", e);
        reject(new Error("Could not parse the Excel file. Ensure it's a valid .xlsx format and descriptions are in the first column of the first sheet."));
      }
    };

    reader.onerror = (errorEvent) => {
      console.error("FileReader error:", errorEvent);
      reject(new Error("Error reading file. The file might be corrupted or inaccessible."));
    };

    reader.readAsBinaryString(file);
  });
};
