import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { RawAnalysisResult } from '../types';

const MODEL_NAME = "gemini-2.5-flash-preview-04-17";

export async function analyzeShoeDescription(
  description: string,
  exclusionTerms: string[]
): Promise<RawAnalysisResult> {
  if (!process.env.API_KEY) {
    // This case should ideally be caught in App.tsx before calling this service
    // but it's a good fallback.
    console.error("API Key is not available in geminiService.");
    throw new Error("API Key is not configured. Please ensure the API_KEY environment variable is set.");
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const exclusionInstructions = exclusionTerms.length > 0
    ? `The following terms or phrases, if found, should be noted as internal customer labels and excluded from the main material/color analysis. List them under 'excludedParts': ${exclusionTerms.map(term => `"${term}"`).join(', ')}.`
    : 'No specific exclusion terms provided; analyze all parts of the description for materials and colors unless they are clearly not part of the shoe itself.';

  const prompt = `
    Analyze the following shoe description:
    "${description}"

    Your tasks are to:
    1.  Identify all materials mentioned. For each material:
        *   Determine if it's a SOLID or REGRIND material. If unsure, classify as UNKNOWN. Base this on explicit mentions like "regrind", "recycled content affecting structure" for REGRIND, or "solid piece", "virgin material" for SOLID. If context implies recycled but used as a simple color fleck or minor non-structural component, it might still be part of a SOLID component. Focus on the primary nature of the described part.
        *   State the exact text mention of the material.
        *   Provide a brief reasoning for your classification (SOLID/REGRIND/UNKNOWN).
    2.  Identify all colors mentioned. For each color:
        *   State the color name as mentioned.
        *   Categorize the color (e.g., Warm Tones, Cool Tones, Neutrals, Metallics, Pastels, Brights, Earth Tones, Multicolor).
        *   State the exact text mention of the color.
    3.  ${exclusionInstructions} If a part of the description matches an exclusion term, or seems like an internal code or label not part of the physical shoe, identify it. For each:
        *   State the matched exclusion term (if applicable) or the identified internal label.
        *   State the exact mention in the text.
        *   Provide a brief reason why it's considered an excluded part (e.g., "Matches provided exclusion term", "Appears to be an internal product code").
        *   Do not include these in the primary material or color analysis results if they are internal labels.
    4.  Provide a brief overall summary of the shoe based on the analyzed description, focusing on its key characteristics.

    Return your analysis STRICTLY in the following JSON format. Do not include any markdown formatting like \`\`\`json or \`\`\` around the JSON block:
    {
      "materials": [
        { "type": "SOLID|REGRIND|UNKNOWN", "mention": "string", "reasoning": "string" }
      ],
      "colors": [
        { "name": "string", "category": "string", "mention": "string" }
      ],
      "excludedParts": [
        { "term": "string", "mention": "string", "reasoning": "string" }
      ],
      "summary": "string"
    }

    Examples:
    - Material Reasoning: "The term 'regrind rubber' explicitly indicates a regrind material." or "Described as 'solid PU foam', indicating a solid material." or "Material type not specified, classified as UNKNOWN."
    - Color Categorization: "Hot Pink" -> "Brights", "Forest Green" -> "Earth Tones", "Silver" -> "Metallics", "Off-white" -> "Neutrals".
    - Excluded Part: If exclusion term is "style_XYZ" and description contains "upper made of leather (style_XYZ)", then an excludedPart could be { "term": "style_XYZ", "mention": "(style_XYZ)", "reasoning": "Matches provided exclusion term for internal labelling." }.
    
    Ensure the JSON is valid and complete.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.15, // Slightly lower for more deterministic analytical tasks
        topK: 32,
        topP: 0.9,
      },
    });

    // The response.text should be a clean JSON string because of responseMimeType: "application/json"
    // However, as a fallback, include fence removal.
    let jsonStr = response.text.trim();
    const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s; // Made regex more robust for optional 'json' after fence
    const match = jsonStr.match(fenceRegex);
    if (match && match[1]) { // Use match[1] which is the content inside the fences
      jsonStr = match[1].trim();
    }
    
    try {
      const parsedData = JSON.parse(jsonStr) as RawAnalysisResult;
      // Validate core structure; individual arrays can be empty.
      if (typeof parsedData.materials === 'undefined' || 
          typeof parsedData.colors === 'undefined' || 
          typeof parsedData.excludedParts === 'undefined' || 
          typeof parsedData.summary === 'undefined') {
          console.error("Parsed JSON is missing one or more core fields (materials, colors, excludedParts, summary):", parsedData);
          throw new Error("Received malformed or incomplete JSON structure from AI. Essential fields are missing.");
      }
      // Ensure arrays are actually arrays, even if empty
      parsedData.materials = Array.isArray(parsedData.materials) ? parsedData.materials : [];
      parsedData.colors = Array.isArray(parsedData.colors) ? parsedData.colors : [];
      parsedData.excludedParts = Array.isArray(parsedData.excludedParts) ? parsedData.excludedParts : [];
      
      return parsedData;
    } catch (e) {
      console.error("Failed to parse JSON response from AI:", e);
      console.error("Raw JSON string from AI that failed parsing:", jsonStr);
      // Provide a more user-friendly part of the error if possible
      const snippet = jsonStr.length > 300 ? jsonStr.substring(0, 300) + "..." : jsonStr;
      throw new Error(`Failed to parse the AI's response. The AI may have returned an invalid format. Received: ${snippet}`);
    }
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    // Check for specific error types if available, e.g., from the SDK
    if (error.message && (error.message.includes("API key") || error.message.includes("API_KEY"))) {
        throw new Error("API Key is invalid, not permitted, or missing. Please check your API_KEY setup.");
    }
    // Add more specific error messages based on potential API errors if known
    // For example, quota issues, model unavailability, etc.
    throw new Error(`An error occurred while communicating with the AI service. ${error.message || 'Please try again later.'}`);
  }
}
