export interface MaterialAnalysis {
  type: "SOLID" | "REGRIND" | "UNKNOWN";
  mention: string;
  reasoning: string;
}

export interface ColorAnalysis {
  name: string;
  category: string; // AI will determine this
  mention: string;
}

export interface ExcludedPart {
  term: string; // The exclusion term that was matched
  mention: string; // The specific text in the description that matched
  reasoning: string; // Why this part was considered excluded by the AI
}

export interface RawAnalysisResult {
  materials: MaterialAnalysis[];
  colors: ColorAnalysis[];
  excludedParts: ExcludedPart[];
  summary: string; // A brief summary of the analysis
}

// This type will be used in the UI, including an ID for React list keys
// and the original description for display.
export interface AnalysisResult extends RawAnalysisResult {
  id: string;
  originalDescription: string;
}

// This could be useful for progress tracking or more detailed error reporting per item in batch
export interface ProcessedItem {
    originalInput: string; // Could be description or row identifier
    status: 'pending' | 'processing' | 'completed' | 'error';
    result?: AnalysisResult;
    error?: string;
}
